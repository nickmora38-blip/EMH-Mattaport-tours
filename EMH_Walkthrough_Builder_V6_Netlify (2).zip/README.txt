EMH Walkthrough Builder V6

Deploy to Netlify by dragging this folder as a ZIP into Netlify Drop.

What works:
- Matterport guided autoplay via URL parameters
- Manual scene autoplay from Matterport deep links
- Browser recording export to WebM
- Team share link generator
- CRM embed generator
- CapCut handoff link

Reality check:
- True automatic sweep-to-sweep generation and per-stop camera rotation require the Matterport Showcase SDK on your final hosted domain.
- This build avoids the SDK by using guided-tour autoplay when available, or manually curated deep links plus browser recording.
